#!/bin/bash
# Uranium Installer v1.0 (safe append)

# Ensure Uranium config folder exists
mkdir -p "$HOME/Uranium"

# Copy Uranium config file
cp ./uraniumrc "$HOME/Uranium/"

# Append sourcing line to ~/.bashrc if it's not already there
if ! grep -Fxq "source \$HOME/Uranium/uraniumrc" "$HOME/.bashrc"; then
    echo "" >> "$HOME/.bashrc"
    echo "# Uranium config" >> "$HOME/.bashrc"
    echo "source \$HOME/.uraniumrc" >> "$HOME/.bashrc"
    echo "Uranium config appended to .bashrc!"
else
    echo "Uranium config already in .bashrc, skipping append."
fi

echo "Installation complete! Open a new terminal to start using Uranium."
